export default function Dashboard(){
  return (
    <div className="container">
      <h1>Área do Aluno</h1>
      <p>Bem-vindo! Aqui estarão as aulas e o progresso.</p>
    </div>
  )
}
