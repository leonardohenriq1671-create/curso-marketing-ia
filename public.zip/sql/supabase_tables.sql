-- users
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  name text,
  created_at timestamptz default now()
);

-- lessons
create table if not exists lessons (
  id serial primary key,
  title text not null,
  description text,
  video_url text,
  module text,
  position int default 0
);

-- enrollments
create table if not exists enrollments (
  id serial primary key,
  email text references users(email),
  course_id int,
  status text,
  unlocked_at timestamptz
);

-- payments
create table if not exists payments (
  id serial primary key,
  email text,
  txid text,
  method text,
  amount numeric,
  status text,
  created_at timestamptz default now()
);
