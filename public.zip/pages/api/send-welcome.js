import nodemailer from 'nodemailer';
export default async function handler(req, res) {
  const { email } = req.body;
  try {
    const transporter = nodemailer.createTransport({ service:'SendGrid', auth:{ user:'apikey', pass: process.env.SENDGRID_API_KEY } });
    await transporter.sendMail({ from:'curso@seusite.com', to: email, subject: 'Acesso liberado!', html: `<p>Seu acesso foi liberado. Acesse: <a href="${process.env.NEXT_PUBLIC_SITE_URL}/dashboard">Minha Área</a></p>` });
    return res.status(200).json({ status:'sent' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}
