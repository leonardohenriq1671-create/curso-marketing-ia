export default function PixPendente({qr, copia}) {
  return (
    <div className="container">
      <h1>Pagamento PIX - Aguardando</h1>
      <p>Escaneie o QR Code ou copie o código abaixo.</p>
      <div style={{background:'#fff', padding:16, borderRadius:8}}>
        <div style={{height:220,display:'flex',alignItems:'center',justifyContent:'center',color:'#444'}}>QR CODE</div>
        <pre style={{background:'#f3f4f6', padding:12, borderRadius:6, marginTop:12}}>{copia || 'copiaecola...'}</pre>
      </div>
    </div>
  )
}
