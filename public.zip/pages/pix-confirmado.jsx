export default function PixConfirmado(){
  return (
    <div className="container">
      <h1>Pagamento Confirmado via PIX 🎉</h1>
      <p>Seu acesso foi liberado. Verifique seu e-mail ou clique abaixo para entrar no curso.</p>
      <a href="/dashboard">Acessar Curso</a>
    </div>
  )
}
