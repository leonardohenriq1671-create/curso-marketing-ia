export default function PixExpirado(){
  return (
    <div className="container">
      <h1>PIX Expirado</h1>
      <p>O PIX expirou. Gere um novo pagamento no checkout.</p>
      <a href="/checkout">Gerar Novo PIX</a>
    </div>
  )
}
