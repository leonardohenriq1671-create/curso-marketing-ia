export default async function handler(req, res) {
  // Mercado Pago webhook payload handling (validate in production)
  const body = req.body;
  console.log('MP webhook', body);
  // Example: call unlock endpoint
  // await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/api/unlock`, { method:'POST', body: JSON.stringify({ email, txid }) })
  res.status(200).send('ok');
}
