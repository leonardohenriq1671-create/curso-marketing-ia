import mercadopago from 'mercadopago';
mercadopago.configure({ access_token: process.env.MP_ACCESS_TOKEN });

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  try {
    const preference = {
      items: [{ title: 'Curso Marketing Digital com IA 2025', quantity: 1, unit_price: 197 }],
      payment_methods: { excluded_payment_types: [{ id: 'credit_card' }] },
      back_urls: { success: `${process.env.NEXT_PUBLIC_SITE_URL}/pix-confirmado`, failure: `${process.env.NEXT_PUBLIC_SITE_URL}/pix-expirado` },
      notification_url: `${process.env.NEXT_PUBLIC_SITE_URL}/api/webhook-mp`
    };
    const response = await mercadopago.preferences.create(preference);
    return res.status(200).json(response);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}
