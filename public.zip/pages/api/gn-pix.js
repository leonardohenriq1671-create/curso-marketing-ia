import fetch from 'node-fetch';
import fs from 'fs';
import https from 'https';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  try {
    const agent = new https.Agent({ pfx: fs.readFileSync(process.env.GN_CERT_PFX_PATH), passphrase: process.env.GN_CERT_PASSWORD });
    const body = { calendario:{expiracao:3600}, valor:{original:'197.00'}, chave: process.env.GN_PIX_KEY, solicitacaoPagador: 'Pagamento do curso' };
    const resp = await fetch(`${process.env.GN_PIX_URL}/v2/cob`, { method:'POST', body: JSON.stringify(body), headers:{'Content-Type':'application/json'}, agent });
    const data = await resp.json();
    return res.status(200).json(data);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}
