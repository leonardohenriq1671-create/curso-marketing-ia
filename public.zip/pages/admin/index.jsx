export default function Admin(){
  return (
    <div className="container">
      <h1>Painel Admin</h1>
      <p>Gerencie alunos, conteúdo e pagamentos.</p>
    </div>
  )
}
