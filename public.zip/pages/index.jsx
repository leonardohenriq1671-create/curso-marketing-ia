import Link from 'next/link';
export default function Home(){
  return (
    <div style={{background:'linear-gradient(180deg,#2563eb,#7c3aed)', color:'white', minHeight:'100vh', padding:48}}>
      <div style={{maxWidth:900, margin:'0 auto', textAlign:'center'}}>
        <h1 style={{fontSize:48, marginBottom:16}}>Aprenda a Ganhar Dinheiro com Marketing Digital e IA em 2025</h1>
        <p style={{fontSize:18, marginBottom:24}}>Curso completo com ferramentas, automações e funil pronto para você implementar.</p>
        <Link href="/checkout"><a style={{background:'#fff', color:'#1f2937', padding:'12px 24px', borderRadius:8, fontWeight:600}}>Quero garantir minha vaga</a></Link>
      </div>
    </div>
  )
}
