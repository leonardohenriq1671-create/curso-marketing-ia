import { supabase } from '../../lib/supabase';
import fetch from 'node-fetch';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  try {
    const { email, txid } = req.body;
    const { data, error } = await supabase.from('enrollments').insert([{ email, course_id:1, status:'active' }]);
    if (error) throw error;
    // send welcome email
    await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/api/send-welcome`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email }) });
    return res.status(200).json({ status: 'ok', data });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}
