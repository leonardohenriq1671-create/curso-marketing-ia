const puppeteer = require('puppeteer');
const fs = require('fs');
(async () => {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  const htmlPath = './public/exports/ebook.html';
  if (!fs.existsSync(htmlPath)) { fs.writeFileSync(htmlPath, '<h1>Ebook</h1>'); }
  const html = fs.readFileSync(htmlPath, 'utf8');
  await page.setContent(html, { waitUntil: 'networkidle0' });
  await page.pdf({ path: 'public/exports/ebook.pdf', format: 'A4' });
  await browser.close();
  console.log('PDF gerado em public/exports/ebook.pdf');
})();
