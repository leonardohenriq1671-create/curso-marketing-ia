export default function Obrigado(){
  return (
    <div className="container">
      <h1>Compra Confirmada!</h1>
      <p>Obrigado pela sua compra. Acesse sua área do aluno:</p>
      <a href="/dashboard">Acessar Curso</a>
    </div>
  )
}
