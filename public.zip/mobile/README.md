Expo app skeleton:
1. expo init mobile-app
2. npm install axios
3. Example: call https://seusite.com/api/lessons to list lessons
