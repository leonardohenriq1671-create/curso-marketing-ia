export default function Checkout(){
  return (
    <div className="container">
      <h1>Checkout - Curso Marketing Digital com IA</h1>
      <p>Preço: R$197,00</p>

      <form action="/api/checkout" method="POST">
        <button type="submit" style={{padding:'12px 20px', background:'#2563eb', color:'white', border:'none', borderRadius:8}}>Pagar com Cartão (Stripe)</button>
      </form>

      <form action="/api/pix-mp" method="POST" style={{marginTop:12}}>
        <button type="submit" style={{padding:'12px 20px', background:'#10b981', color:'white', border:'none', borderRadius:8}}>Pagar com PIX (Mercado Pago)</button>
      </form>

      <form action="/api/gn-pix" method="POST" style={{marginTop:12}}>
        <button type="submit" style={{padding:'12px 20px', background:'#7c3aed', color:'white', border:'none', borderRadius:8}}>Pagar com PIX (Gerencianet)</button>
      </form>
    </div>
  )
}
