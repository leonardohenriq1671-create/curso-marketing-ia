import { stripe } from '../../lib/stripe';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/obrigado`,
      cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/pix-expirado`,
      line_items: [{
        price_data: { currency: 'brl', product_data: { name: 'Curso Marketing Digital com IA 2025' }, unit_amount: 19700 },
        quantity: 1
      }]
    });
    return res.status(200).json({ url: session.url });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}
